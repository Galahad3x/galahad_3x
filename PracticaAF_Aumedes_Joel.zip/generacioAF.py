import sys

filename = "auto.hs"

if len(sys.argv) >= 2:
    if sys.argv[1].endswith(".hs"):
        print("L'AFD es guardarà al fitxer " + str(sys.argv[1]))
        filename = sys.argv[1]
    else:
        print("L'AFD es guardarà al fitxer " + str(sys.argv[1]) + ".hs")
        filename = str(sys.argv[1]) + ".hs"

estats = list(set([int(x) for x in input("Introdueix la llista d'estats separats per comes: ").split(",")]))
alfabet = []
while len(alfabet) == 0:
    alfabet = list(set(input("Introdueix l'alfabet separat per comes {a,b}: ").split(",")))
    if len(alfabet) == 0:
        print("ERROR: L'alfabet no pot estar buit")
estats_i = list(
    set([int(x) for x in input("Introdueix la llista d'estats incials separats per comes: ").split(",")]))
while len(estats_i) == 0:
    print("ERROR: Els estats inicials no poden ser buits")
    estats_i = list(
        set([int(x) for x in input("Introdueix la llista d'estats incials separats per comes: ").split(",")]))
estats_f = list(
    set([int(x) for x in input("Introdueix la llista d'estats finals separats per comes: ").split(",")]))
while len(estats_f) == 0:
    print("ERROR: Els estats finals no poden ser buits")
    estats_f = list(
        set([int(x) for x in input("Introdueix la llista d'estats finals separats per comes: ").split(",")]))

for st in estats_i:
    if st not in estats:
        print("ERROR: Estat inicial no és a la llista d'estats. S'afegirà")
        estats.append(st)

for st in estats_f:
    if st not in estats:
        print("ERROR: Estat final no és a la llista d'estats. S'afegirà")
        estats.append(st)

fdt = {}
estats.sort()
alfabet.sort()

for st in estats:
    for ch in alfabet:
        llista = input("Introdueix els resultats de la funció de transició de " + "(" + str(st) + "," + str(
            ch) + ")" + " separats per comes {0,1,2}: ").split(",")
        llista2 = []
        for x in llista:
            if x != '':
                llista2.append(int(x))
        fdt["(" + str(st) + "," + str(ch) + ")"] = list(set(llista2))

determinista = True

if len(estats_i) != 1:
    determinista = False
else:
    for st in estats:
        for ch in alfabet:
            if len(fdt["(" + str(st) + "," + str(ch) + ")"]) != 1:
                determinista = False

if not determinista:
    estats_rev = [estats_i]
    queue_rev = [estats_i]
    estats_new = [estats_i]
    estats_f_new = []
    estat_i_new = estats_i
    fdt_new = {}
    while len(queue_rev) != 0:
        for ch in alfabet:
            estats_resultat = []
            for st in queue_rev[0]:
                estats_resultat.extend(fdt["(" + str(st) + "," + str(ch) + ")"])
            estats_resultat = list(set(estats_resultat))
            estats_resultat.sort()
            if estats_resultat not in estats_rev and estats_resultat not in estats_new:
                estats_new.append(estats_resultat)
                for est in estats_new[-1]:
                    if estats_new[-1] not in estats_f_new and est in estats_f:
                        estats_f_new.append(estats_new[-1])
                if estats_resultat not in queue_rev:
                    queue_rev.append(estats_resultat)
            fdt_new["(" + str(queue_rev[0]) + "," + str(ch) + ")"] = list(set(estats_resultat))
            fdt_new["(" + str(queue_rev[0]) + "," + str(ch) + ")"].sort()
        queue_rev = queue_rev[1:]
    estats_coded = []
    fdt_coded = {}
    estat_i_coded = 0
    estats_f_coded = []
    cont = 0
    guia = {}
    for st in estats_new:
        guia[str(st)] = cont
        estats_coded.append(cont)
        for key in fdt_new.keys():
            if str(st) in key:
                new_key = key
                new_key = new_key.replace(str(st), str(cont))
                fdt_coded[new_key] = fdt_new[key]
        if st == estat_i_new:
            estat_i_coded = cont
        if st in estats_f_new:
            estats_f_coded.append(cont)
        cont += 1
    for key in fdt_coded.keys():
        for key2 in guia.keys():
            if str(fdt_coded[key]) == key2:
                fdt_coded[key] = guia[key2]
    estats = estats_coded
    fdt = fdt_coded
    estats_i = estat_i_coded
    estats_f = estats_f_coded
else:
    estats_i = estats_i[0]
    for st in estats:
        for ch in alfabet:
            fdt["(" + str(st) + "," + str(ch) + ")"] = int(fdt["(" + str(st) + "," + str(ch) + ")"][0])

with open(filename, "w+") as f:
    f.write("import AutomatM\n\nmain = llegirParaules autom\n\n")
    f.write("stts2 :: [Int]\n")
    f.write("stts2 = " + str(estats) + "\n")
    f.write("alf2 :: [Char]\n")
    f.write("alf2 = " + str(alfabet) + "\n")
    f.write("q2 :: Int\n")
    f.write("q2 = " + str(estats_i) + "\n")
    f.write("sttsF2 :: [Int]\n")
    f.write("sttsF2 = " + str(estats_f) + "\n")
    f.write("fdt2 :: (Int -> Char -> Int)\n")
    for st in estats:
        for ch in alfabet:
            f.write("fdt2 " + str(st) + " '" + str(ch) + "' = " + str(fdt["(" + str(st) + "," + str(ch) + ")"]) + "\n")
    f.write("fdt2 _ x = -1\n")
    f.write("\nautom = Automat {stts = stts2,alf = alf2, fdt = fdt2, q = q2, sttsF = sttsF2 }\n")

print("AFD generat al fitxer " + str(filename))
print("Per a realitzar la lectura de paraules, executar:\nrunhaskell " + str(filename))
