module AutomatM(
Automat(..),
llegirParaula,
llegirParaules
)where

data Automat = Automat {stts :: [Int],alf :: [Char],fdt :: (Int -> Char -> Int),q :: Int,sttsF :: [Int] }

llegirParaules atm = do
    putStr $ "Introdueix la paraula a comprovar: "    
    line <- getLine
    if null line
        then return ()
        else do
            putStrLn $ llegirParaula atm line
            llegirParaules atm

llegirParaula :: Automat -> [Char] -> String
llegirParaula auto par = if (llegir auto par) `elem` (sttsF auto) then "Paraula acceptada" else "Paraula no acceptada"

llegir :: Automat -> [Char] -> Int
llegir auto par = foldl (fdt auto) (q auto) par

